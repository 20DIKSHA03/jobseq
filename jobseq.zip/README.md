# Job Scheduling Project
This repository contains a C++ program for scheduling jobs to maximize profit.

## Files
- `2.cpp`: Contains the C++ job scheduling code.
- `README.md`: Project description.
